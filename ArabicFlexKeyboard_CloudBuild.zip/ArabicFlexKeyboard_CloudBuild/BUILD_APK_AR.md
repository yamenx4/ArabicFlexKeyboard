# بناء APK — خطوة واحدة تقريباً

## Android Studio

1. فك ضغط المشروع وافتح مجلد `ArabicFlexKeyboard_Android16_ReadyToBuild` في Android Studio.
2. انتظر Gradle Sync.
3. من القائمة اختر:
   **Build > Generate App Bundles or APKs > Generate APKs**
4. ملف الـAPK التجريبي سيكون:
   `app/build/outputs/apk/debug/app-debug.apk`

الـDebug APK موقّع تلقائياً بمفتاح debug ويمكن تثبيته مباشرة على جهازك.

## إذا أردت زر Run فقط

اضغط زر ▶ Run في Android Studio. هذا يبني التطبيق ويثبته على الجهاز/المحاكي.

## تعديل الكيبورد

قبل البناء عدّل:

`app/src/main/assets/keyboard.json`

للإيموجي والحروف والأزرار.

وللألوان:

`app/src/main/assets/theme.json`

بعد ذلك أعد Build APK.

## MT Manager

بعد الحصول على `app-debug.apk` يمكنك فتحه في MT Manager وتعديل ملفات `assets/keyboard.json` و`assets/theme.json` ثم إعادة توقيع APK.

## Android 16

المشروع مضبوط على:
- compileSdk 36
- targetSdk 36
- minSdk 23
- Java 17
