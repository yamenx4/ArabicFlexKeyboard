# بناء APK بدون Android Studio

هذه النسخة مجهزة للبناء السحابي بواسطة GitHub Actions.

## من الهاتف

1. أنشئ مستودعاً جديداً على GitHub، مثلاً:
   `ArabicFlexKeyboard`
2. ارفع محتويات هذا المجلد إلى المستودع، وليس ملف ZIP نفسه.
3. افتح تبويب **Actions**.
4. اختر **Build APK**.
5. اضغط **Run workflow** إذا لم يبدأ البناء تلقائياً.
6. بعد انتهاء البناء افتح صفحة الـWorkflow ثم قسم **Artifacts**.
7. نزّل:
   `ArabicFlexKeyboard-APK`
8. فك الضغط وستجد:
   `app-debug.apk`

لا تحتاج Android Studio ولا Android SDK على هاتفك. البناء يتم على خوادم GitHub.

## مهم
- المشروع يستهدف Android 16 / API 36.
- الـAPK الناتج Debug وموقّع بمفتاح Debug الخاص بالبناء.
- يمكنك تثبيته على هاتفك، وبعدها فتح الـAPK في MT Manager للتعديل.
