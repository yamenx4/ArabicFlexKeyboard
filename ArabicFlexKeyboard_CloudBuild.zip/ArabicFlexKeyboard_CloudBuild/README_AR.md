# Arabic Flex Keyboard — Android 16

مشروع كيبورد عربي قابل للتعديل ومجهز للبناء في Android Studio.

### الملفات المهمة
- `app/src/main/assets/keyboard.json` — الحروف والإيموجي والأزرار.
- `app/src/main/assets/theme.json` — ألوان أساسية قابلة للتعديل.
- `FlexKeyboardService.java` — منطق الكيبورد.
- `SettingsActivity.java` — صفحة التفعيل والاختيار.

### الميزات الحالية
- عربي.
- إيموجي.
- حذف / Enter / مسافة / لغة / فاصلة / نقطة.
- إعدادات بسيطة لتفعيل واختيار الكيبورد.
- targetSdk 36 / compileSdk 36.

هذه نسخة أساس قابلة للتوسعة، وليست نسخة مطابقة حرفياً للكيبورد الموجود في الصور.
