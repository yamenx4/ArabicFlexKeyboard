package com.abokees.flexkeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.inputmethod.InputConnection;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class FlexKeyboardService extends InputMethodService {
    private LinearLayout root;
    private JSONObject cfg;

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public View onCreateInputView() {
        cfg = loadConfig();
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(5), dp(5), dp(5), dp(5));
        root.setBackgroundColor(Color.rgb(238,241,244));
        buildKeyboard();
        return root;
    }

    private JSONObject loadConfig() {
        try {
            InputStream in = getAssets().open("keyboard.json");
            byte[] data = new byte[in.available()];
            in.read(data); in.close();
            return new JSONObject(new String(data, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private TextView key(String text, boolean action) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setGravity(Gravity.CENTER);
        v.setTextSize(action ? 17 : 21);
        v.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        v.setTextColor(action ? Color.WHITE : Color.rgb(17,17,17));
        v.setSingleLine(true);
        v.setBackground(action ? getDrawableSafe(com.abokees.flexkeyboard.R.drawable.action_bg)
                                : getDrawableSafe(com.abokees.flexkeyboard.R.drawable.key_bg));
        v.setOnClickListener(x -> press(text));
        return v;
    }

    private Drawable getDrawableSafe(int id) {
        return getResources().getDrawable(id, getTheme());
    }

    private void addRow(JSONArray arr, boolean emoji) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setWeightSum(Math.max(1, arr.length()));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(47));
        rp.topMargin = dp(3);
        root.addView(row, rp);

        for (int i=0; i<arr.length(); i++) {
            String s = arr.optString(i, "");
            TextView v = key(s, false);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1);
            p.setMargins(dp(2), 0, dp(2), 0);
            row.addView(v, p);
        }
    }

    private void buildKeyboard() {
        try {
            JSONArray er = cfg.optJSONArray("emojiRows");
            if (er != null) for (int i=0; i<er.length(); i++) addRow(er.getJSONArray(i), true);

            JSONArray ar = cfg.optJSONArray("arabicRows");
            if (ar != null) for (int i=0; i<ar.length(); i++) addRow(ar.getJSONArray(i), false);

            JSONObject a = cfg.optJSONObject("actions");
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(50));
            rp.topMargin = dp(4);
            root.addView(row, rp);

            addAction(row, a != null ? a.optString("language","🌐") : "🌐", 1.0f);
            addAction(row, a != null ? a.optString("comma","،") : "،", 1.0f);
            addAction(row, a != null ? a.optString("space","مسافة") : "مسافة", 2.8f);
            addAction(row, a != null ? a.optString("dot",".") : ".", 1.0f);
            addAction(row, a != null ? a.optString("backspace","⌫") : "⌫", 1.2f);
            addAction(row, a != null ? a.optString("enter","↵") : "↵", 1.2f);
        } catch (Exception ignored) {}
    }

    private void addAction(LinearLayout row, String s, float weight) {
        TextView v = key(s, true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, weight);
        p.setMargins(dp(2), 0, dp(2), 0);
        row.addView(v, p);
    }

    private void press(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (s.equals("⌫")) {
            ic.deleteSurroundingText(1, 0);
        } else if (s.equals("↵")) {
            ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER));
            ic.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER));
        } else if (s.equals("مسافة")) {
            ic.commitText(" ", 1);
        } else if (s.equals("🌐")) {
            switchToNextInputMethod(false);
        } else {
            ic.commitText(s, 1);
        }
    }
}
