package com.abokees.flexkeyboard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class SettingsActivity extends Activity {
    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(28), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(238,241,244));

        TextView title = new TextView(this);
        title.setText("Arabic Flex Keyboard");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(20,20,20));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("كيبورد عربي قابل للتعديل. لتضيف أزرار/إيموجي عدّل assets/keyboard.json ثم أعد بناء APK.");
        hint.setTextSize(16);
        hint.setTextColor(Color.DKGRAY);
        hint.setPadding(0, dp(12), 0, dp(20));
        root.addView(hint);

        Button enable = new Button(this);
        enable.setText("تفعيل الكيبورد");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable, new LinearLayout.LayoutParams(-1, dp(54)));

        Button choose = new Button(this);
        choose.setText("اختيار الكيبورد");
        choose.setOnClickListener(v -> {
            android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.topMargin = dp(10);
        root.addView(choose, p);

        TextView note = new TextView(this);
        note.setText("\nAndroid 16 / API 36\n• عربي + إيموجي\n• أزرار قابلة للتعديل من JSON\n• Backspace / Enter / Space / لغة\n• مناسب للتعديل عبر MT Manager بعد البناء");
        note.setTextSize(15);
        note.setTextColor(Color.DKGRAY);
        root.addView(note);

        setContentView(root);
    }
}
