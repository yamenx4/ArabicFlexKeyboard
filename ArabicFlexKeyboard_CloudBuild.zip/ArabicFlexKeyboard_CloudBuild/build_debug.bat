@echo off
echo Building Arabic Flex Keyboard debug APK...
gradlew.bat assembleDebug
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
